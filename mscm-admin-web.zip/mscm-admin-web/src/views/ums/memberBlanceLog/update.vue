<template> 
  <memberBlanceLog-detail :is-edit='true'></memberBlanceLog-detail>
</template>
<script>
  import MemberBlanceLogDetail from './components/MemberBlanceLogDetail'
  export default {
    name: 'updateMemberBlanceLog',
    components: { MemberBlanceLogDetail }
  }
</script>
<style>
</style>


