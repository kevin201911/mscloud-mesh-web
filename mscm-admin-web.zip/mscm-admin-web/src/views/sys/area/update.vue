<template> 
  <area-detail :is-edit='true'></area-detail>
</template>
<script>
  import AreaDetail from './components/AreaDetail'
  export default {
    name: 'updateArea',
    components: { AreaDetail }
  }
</script>
<style>
</style>


