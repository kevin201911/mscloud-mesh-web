<template> 
  <admin-detail :is-edit='true'></admin-detail>
</template>
<script>
  import AdminDetail from './components/AdminDetail'
  export default {
    name: 'updateAdmin',
    components: { AdminDetail }
  }
</script>
<style>
</style>


